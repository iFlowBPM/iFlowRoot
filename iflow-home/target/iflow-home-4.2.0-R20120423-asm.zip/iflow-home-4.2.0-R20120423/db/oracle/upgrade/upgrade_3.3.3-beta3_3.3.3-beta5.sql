alter table event_data add userid varchar2(32);
