alter table documents add docurl varchar2(2000);
