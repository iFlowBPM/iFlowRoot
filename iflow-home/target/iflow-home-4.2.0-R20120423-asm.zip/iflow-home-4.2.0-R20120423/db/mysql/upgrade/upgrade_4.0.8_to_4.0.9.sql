alter table activity_history add INDEX IND_ACTIVITY_HISTORY_PID (pid);
