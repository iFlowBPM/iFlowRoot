alter table event_data add userid varchar(32);
