mysql-connector.jar - Versao 5.0.8 (A versão 5.1.6 é case sensitive e causa transtorno)
ojdbc14.jar - Oracle 10 ?
ojdbc5.jar - Oracle 11.1.0.1 instant client (não experimentei)
ojdbc6.jar - Oracle 11.1.0.1 instant client (não experimentei)
